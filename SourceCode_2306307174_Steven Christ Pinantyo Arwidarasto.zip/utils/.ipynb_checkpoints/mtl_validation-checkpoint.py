import torch
from torch.nn import MSELoss
from torch.nn.functional import softmax
from torchmetrics.image import PeakSignalNoiseRatio, StructuralSimilarityIndexMeasure
from modules.utils import load_image, save_image, to_categorical, Evaluator
from tqdm import tqdm
import numpy as np
import time
import os
import json
import numpy as np

METRIC_PATH = ".././Ckpt/RS/GID5/validation_metric.json"

def segmentation_metric(default_path, model, datasets, n_class, device, colour_codes, method="MTLPretrained", input_shape=(256, 256, 3), is_hazy=True):
    metrics_func = Evaluator(num_class=n_class)
    div_metrics_func = Evaluator(num_class=n_class)
    
    test_score = {
        'l2':[],
        'psnr':[],
        'ssim':[],
        'miou':[],
        'dice':[],
        'iou':[],
        'oa':[],
        'times':[]
    }
    metrics_func.reset()
    
    for index, i in enumerate(tqdm(datasets)):
        div_metrics_func.reset()
        
        # Load Dataset
        x = load_image(i[0 if is_hazy else 1])
        y = load_image(i[2])
        
        y = to_categorical(y)
        y = np.argmax(y, axis=-1)
        
        # Normalization [0, 1]
        x = torch.as_tensor(x).to(torch.float32) / 255.
        y = torch.as_tensor(y).to(torch.long)
        
        # Konversi dari (H, W, C) ke (C, H, W) sesuai requirement Conv2 Pytorch
        x = torch.permute(x, (2, 0, 1))

        x = x[None, ...].to(device)
        y = y[None,...].to(device)
        
        
        # Predict
        with torch.no_grad():
            start = time.time()
            pred = model(x)
            test_score['times'].append(time.time()-start)
            
        pred = softmax(pred, dim=1)

        metrics_func.add_batch(
            y, 
            pred.argmax(dim=1)
        )

        div_metrics_func.add_batch(
            y, 
            pred.argmax(dim=1)
        )

        # Stored Metrics
        test_score['miou'].append(div_metrics_func.meanIntersectionOverUnion().cpu().data.numpy().item())
        test_score['oa'].append(div_metrics_func.OA().cpu().data.numpy().item())
        test_score['dice'].append(np.nanmean(div_metrics_func.F1().cpu().data.numpy()).item())

        if index < 30:
            save_image(
                image=colour_codes[pred.argmax(dim=1).cpu().detach().numpy()[0]].astype(np.uint8), 
                path=i[0], 
                save_path=default_path, 
                method=method,
                is_hazy=is_hazy,
                mode="segmentation"
            )

    save_metrics(
        metrics={
            "times":list(test_score['times']),
            "miou":list(test_score['miou']),
            "oa":list(test_score['oa']),
            "dice":list(test_score['dice']),
        }, 
        model=method,
        mode="hazy" if is_hazy else "clear"
    )
    
    test_score['miou'] = metrics_func.meanIntersectionOverUnion().cpu().data.numpy().item()
    test_score['dice'] = metrics_func.F1().cpu().data.numpy()
    test_score['iou'] = metrics_func.Intersection_over_Union().cpu().data.numpy()
    test_score['oa'] = metrics_func.OA().cpu().data.numpy().item()
    test_score['times'] = np.mean(np.asarray(test_score['times']))

    return test_score

def save_metrics(metrics, model, mode):
    print(os.getcwd())
    if os.path.exists(METRIC_PATH):
        with open(METRIC_PATH, "r") as f: 
            global_metrics = json.load(f)
    else:
        global_metrics = {}

    if model not in list(global_metrics.keys()):
        global_metrics[model] = {}

    global_metrics[model][mode] = metrics

    with open(METRIC_PATH, "w") as f: 
        json.dump(global_metrics, f)
        

def evaluation_metric(default_path, model, datasets, n_class, device, colour_codes, method="MTLPretrained", input_shape=(256, 256, 3), is_hazy=True, activation=softmax, reverse=False):
    criterion = MSELoss().to(device)
    criterion_psnr = PeakSignalNoiseRatio(data_range=1.0).to(device)
    criterion_ssim = StructuralSimilarityIndexMeasure(data_range=1.0).to(device)
    metrics_func = Evaluator(num_class=n_class)
    div_metrics_func = Evaluator(num_class=n_class)
    
    test_score = {
        'l2':[],
        'psnr':[],
        'ssim':[],
        'miou':[],
        'dice':[],
        'iou':[],
        'oa':[],
        'times':[]
    }
    metrics_func.reset()
    
    for index, i in enumerate(tqdm(datasets)):
        div_metrics_func.reset()
        
        # Load Dataset
        x = load_image(i[0 if is_hazy else 1])
        y_rec = load_image(i[1])
        y = load_image(i[2])
        
        y = to_categorical(y)
        y = np.argmax(y, axis=-1)
        
        # Normalization [0, 1]
        x = torch.as_tensor(x).to(torch.float32) / 255.
        y_rec = torch.as_tensor(y_rec).to(torch.float32) / 255.
        y = torch.as_tensor(y).to(torch.long)
        
        # Konversi dari (H, W, C) ke (C, H, W) sesuai requirement Conv2 Pytorch
        x = torch.permute(x, (2, 0, 1))
        y_rec = torch.permute(y_rec, (2, 0, 1))

        x = x[None, ...].to(device)
        y_rec = y_rec[None, ...].to(device)
        y = y[None,...].to(device)
        
        
        # Predict
        with torch.no_grad():
            start = time.time()

            if reverse:
                pred, recons = model(x)
            else:
                recons, pred = model(x)
            test_score['times'].append(time.time()-start)

        if activation != None:
            pred = softmax(pred, dim=1)

        metrics_func.add_batch(
            y, 
            pred.argmax(dim=1)
        )
        
        div_metrics_func.add_batch(
            y, 
            pred.argmax(dim=1)
        )

        test_score['l2'].append(criterion(recons, y_rec).cpu().data.numpy().item())
        
        # Normalize [0, 1]
        recons = torch.clamp(recons, 0, 1)
        y_rec = torch.clamp(y_rec, 0, 1)

        test_score['psnr'].append(np.nan_to_num(criterion_psnr(recons, y_rec).cpu().data.numpy()).item())
        test_score['ssim'].append(np.nan_to_num(criterion_ssim(recons, y_rec).cpu().data.numpy()).item())

        test_score['miou'].append(np.nan_to_num(div_metrics_func.meanIntersectionOverUnion().cpu().data.numpy()).item())
        test_score['oa'].append(np.nan_to_num(div_metrics_func.OA().cpu().data.numpy()).item())
        test_score['dice'].append(np.nan_to_num(np.nanmean(div_metrics_func.F1().cpu().data.numpy())).item())

        if index < 30:
            save_image(
                image=colour_codes[pred.argmax(dim=1).cpu().detach().numpy()[0]].astype(np.uint8), 
                path=i[0], 
                save_path=default_path, 
                method=method,
                is_hazy=is_hazy,
                mode="segmentation"
            )

            save_image(
                image=recons[0].cpu().detach().numpy().transpose(1, 2, 0), 
                path=i[0], 
                save_path=default_path, 
                method=method,
                is_hazy=is_hazy,
                mode="reconstruction"
            )
            
    save_metrics(
        metrics={
            "psnr":list(test_score['psnr']),
            "ssim":list(test_score['ssim']),
            "l2":list(test_score['l2']),
            "times":list(test_score['times']),
            "miou":list(test_score['miou']),
            "oa":list(test_score['oa']),
            "dice":list(test_score['dice']),
        }, 
        model=method,
        mode="hazy" if is_hazy else "clear"
    )

    test_score['miou'] = metrics_func.meanIntersectionOverUnion().cpu().data.numpy()
    test_score['dice'] = metrics_func.F1().cpu().data.numpy()
    test_score['iou'] = metrics_func.Intersection_over_Union().cpu().data.numpy()
    test_score['oa'] = metrics_func.OA().cpu().data.numpy()
    test_score['times'] = np.mean(np.asarray(test_score['times']))
    test_score['psnr'] = np.asarray(np.mean(test_score['psnr']))
    test_score['ssim'] = np.asarray(np.mean(test_score['ssim']))

    return test_score